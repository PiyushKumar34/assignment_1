num1 = float(input('Enter the number of seconds:'))
MIN= num1/60
SEC= num1%60
print ("the number of minutes: %d" %MIN)
print ("the number of minutes: %d" %SEC)