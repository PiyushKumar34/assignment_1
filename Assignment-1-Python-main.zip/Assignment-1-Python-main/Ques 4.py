a=25
b='25'
c=25.0

sum=str(a+ int(b)+ int(c))
print(sum)