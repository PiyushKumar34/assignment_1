#Ques 1
a = int(input('Enter first number: '))
b = int(input('Enter second number: '))
c = int(input('Enter third number: '))
avg = (a+b+c)/3
print('The average of numbers = ' ,avg)
